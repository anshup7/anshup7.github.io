var map;
var marker_locs;


function initMap() {

    map = new google.maps.Map(document.getElementById("map"), {
        center: {
            lat: 28.6433,
            lng: 77.3827
        },
        zoom: 12
    });




    marker_locs = { // Add details here to see the marker in application
        positions: [{
                lat: 28.6433,
                lng: 77.3827,
                address: "F-805 Nirala Eden Park(My home)",
                id: "1"
            },
            {
                lat: 28.6469,
                lng: 77.3707,
                address: "St. Teresa school(I studied Here)",
                id: "2"
            },
            {
                lat: 28.6387,
                lng: 77.3606,
                address: "Aditya Mall(My movie Place)",
                id: "3"
            },
            {
                lat: 28.6403,
                lng: 77.3615,
                address: "My Gym Place",
                id: "4"
            },
            {
                lat: 28.6469,
                lng: 77.2195,
                address: "Connought Place(My favorite Destination)",
                id: "5"
            }

        ]
    }

    marker_locs.positions.forEach(function (loc) {
        var marker = new google.maps.Marker({
            position: {
                lat: loc.lat,
                lng: loc.lng
            },
            map: map,
            animation: google.maps.Animation.DROP,
            title: loc.address
        });

        loc.infoWindow = new google.maps.InfoWindow({
            content: loc.address
        });

        marker.addListener('click', function () {
            loc.infoWindow.open(map, this);
            if (this.getAnimation() !== null) {
                this.setAnimation(null);
            } else {
                this.setAnimation(google.maps.Animation.BOUNCE);
            }

        });

        loc.marker_ref = marker;
    });

}