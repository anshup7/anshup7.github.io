
function abc() {
    var $body = $('body');
    var $wikiElem = $('#wikipedia-links');
    var $nytHeaderElem = $('#nytimes-header');
    var $nytElem = $('#nytimes-articles');
    var $greeting = $('#greeting');
    var $location1 = $("#street").val();
    var $location2 = $("#city").val();
    var $location = $location1+", "+$location2;
    var $url = 'https://maps.googleapis.com/maps/api/streetview?size=700x800&location='
    var $image  = "<img class='bgimg' src='"+$url+$location+"'>"
    // clear out old data before new request
    // $wikiElem.text("");
    // $nytElem.text("");

    // load streetview

    $body.append($image);
    // alert($location);
    console.log($location);
    return false;
};


