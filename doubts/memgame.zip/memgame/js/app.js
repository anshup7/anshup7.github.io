/*
 * Create a list that holds all of your cards
 */ 
var card = {
		showing: false, //Determines If any card has been shown?
		currentlyOpened: ""
};
var squares = ["4","9","36","25","49","64","100","121"];
var shuffled = [];
var domArray = [];

//Have a counter to know if the game is completed or not.
//You will alsp need to take care about currently matched pairs, remove events watch on them instead
/*
 * Display the cards on the page
 *   - shuffle the list of cards using the provided "shuffle" method below
 *   - loop through each card and create its HTML
 *   - add each card's HTML to the page
 */

// Shuffle function from http://stackoverflow.com/a/2450976
function shuffle(array) {
    var currentIndex = array.length, temporaryValue, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}

$(document).ready(function () {

		function domShuffle() {
			$("#parent").empty();
			domArray = $("#parent").children().toArray();
			shuffled = shuffle(domArray);
			shuffled.forEach(function (element) {
				$("#parent").append(element);
			});
		}
});


/*
 * set up the event listener for a card. If a card is clicked:
 *  - display the card's symbol (put this functionality in another function that you call from this one)
 *  - add the card to a *list* of "open" cards (put this functionality in another function that you call from this one)
 *  - if the list already has another card, check to see if the two cards match
 *    + if the cards do match, lock the cards in the open position (put this functionality in another function that you call from this one)
 *    + if the cards do not match, remove the cards from the list and hide the card's symbol (put this functionality in another function that you call from this one)
 *    + increment the move counter and display it on the page (put this functionality in another function that you call from this one)
 *    + if all cards have matched, display a message with the final score (put this functionality in another function that you call from this one)
 */

 function removeAttribute(id) {
 	$("#"+id).removeAttr("onclick");
 	$("#"+id).removeAttr("id");
 	$("#"+card.currentlyOpened).removeAttr("id");
 	$("#"+card.currentlyOpened).removeAttr("onclick");
 }

 function resetCard() {
 	card.showing = false;
 	card.currentlyOpened = "";
 }

 function resetGameState(id) { 
   $("#"+card.currentlyOpened).removeClass("show");
   $("#"+card.currentlyOpened).removeClass("open");

   resetCard();

   $("#"+id).removeClass("show");
   $("#"+id).removeClass("open");
 }


	function findPair(id) {  
		var secondElement;
		var tempVar = String(id * id); //Need to use String for performing matching with inArray().
		//Below is the simple logic to find the pairs
		if(jQuery.inArray(tempVar, squares) !== -1) { // inArray() returns the indexOf found value else -1
			secondElement = id * id;
		} else {
			secondElement = Math.sqrt(id); // By logic secondElement == card.currentlyOpened if some card is already opened.
		}

		if(!card.showing) { //If no other card is opened
			$("#"+id).addClass("show");
			$("#"+id).addClass("open");
			card.showing = true;
			card.currentlyOpened = id;
		} else {  // Will execute if some card is being shown
			 if(card.currentlyOpened == secondElement) { // If the second click is made, some card is being shown nd second element calculated is the currently opened element.
			 	$("#"+id).addClass("show");
				$("#"+id).addClass("open");
				removeAttribute(id); //Required so as to alienate matched cards from being modified by JS
				resetCardObject(); // Matched.. No need for DOM changes any further.
			 } else { 
			 	$("#"+id).addClass("show");
				$("#"+id).addClass("open");
				setTimeout(function() {resetGameState(id)}, 700); //will be called when some card is already opened and the second card doesn't matches with the previously opened one.

			 }
		}
	}


	
