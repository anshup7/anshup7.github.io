/* feedreader.js
 *
 * This is the spec file that Jasmine will read and contains
 * all of the tests that will be run against your application.
 */

/* We're placing all of our tests within the $() function,
 * since some of these tests may require DOM elements. We want
 * to ensure they don't run until the DOM is ready.
 */
 var spyEvent;

$(function() {
    /* This is our first test suite - a test suite just contains
    * a related set of tests. This suite is all about the RSS
    * feeds definitions, the allFeeds variable in our application.
    */
    describe('RSS Feeds', function() {
        /* This is our first test - it tests to make sure that the
         * allFeeds variable has been defined and that it is not
         * empty. Experiment with this before you get started on
         * the rest of this project. What happens when you change
         * allFeeds in app.js to be an empty array and refresh the
         * page?
         */
        it('are defined', function() {
            expect(allFeeds).toBeDefined();
            expect(allFeeds.length).not.toBe(0);
        });


        it('All URL(s) are defined and have the truthy values.', function() { // Test case that ensures all URls are defined and don't have the empty values.
            allFeeds.forEach(function(container) {
                expect(container.url).toBeDefined();
                expect(container.url).toBeTruthy();
            });
        });

        it('All name(s) are defined and have the truthy values.', function() { // Test case that ensures all name(s) are defined and don't have the empty values.
            allFeeds.forEach(function(container) {
                expect(container.name).toBeDefined();
                expect(container.name).toBeTruthy();
            });
        });

    });


    describe("The menu", function() {

    
        it("Menu Element is Hidden by default", function(){
            expect($('body').attr('class')).toMatch("menu-hidden");
        });

        xit("Menu Hamburger Icon works correctly", function(){
           
                // spyEvent = spyOnEvent('#hamburger', 'click');
                // $('#hamburger').trigger( "click" );
       
                // expect('click').toHaveBeenTriggeredOn('#hamburger');
                // expect(spyEvent).toHaveBeenTriggered();  
            
        });

    });


    /* TODO: Write a new test suite named "The menu" */


         /* TODO: Write a test that ensures the menu changes
          * visibility when the menu icon is clicked. This test
          * should have two expectations: does the menu display when
          * clicked and does it hide when clicked again.
          */


          describe("Initial Entries", function() {
            var originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
                beforeEach(function(done){
                    jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
                    init(function(){

                        done();

                    });
                });

                it("Feed Reader Conatiner has atleast a single entry element", function(){
                    expect(feedSet).toBe(true);
                    done();
                });

                afterEach(function() {
                    jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
                })
          });

    /* TODO: Write a new test suite named "Initial Entries" */

        /* TODO: Write a test that ensures when the loadFeed
         * function is called and completes its work, there is at least
         * a single .entry element within the .feed container.
         * Remember, loadFeed() is asynchronous so this test will require
         * the use of Jasmine's beforeEach and asynchronous done() function.
         */

    /* TODO: Write a new test suite named "New Feed Selection" */

        /* TODO: Write a test that ensures when a new feed is loaded
         * by the loadFeed function that the content actually changes.
         * Remember, loadFeed() is asynchronous.
         */
}());
