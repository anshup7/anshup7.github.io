/* feedreader.js
 *
 * This is the spec file that Jasmine will read and contains
 * all of the tests that will be run against your application.
 */
/* We're placing all of our tests within the $() function,
 * since some of these tests may require DOM elements. We want
 * to ensure they don't run until the DOM is ready.
 */
$(function () {
    /* This is our first test suite - a test suite just contains
     * a related set of tests. This suite is all about the RSS
     * feeds definitions, the allFeeds variable in our application.
     */
    describe('RSS Feeds', function () {


        it('are defined', function () { //Test for length and definition of the array.
            expect(allFeeds).toBeDefined();
            expect(allFeeds.length).not.toBe(0);
        });


        it('All URL(s) are defined and have the truthy values.', function () { // Test case that ensures all URls are defined and don't have the empty values.
            allFeeds.forEach(function (container) {
                expect(container.url).toBeDefined();
                expect(container.url).toBeTruthy();
            });
        });

        it('All name(s) are defined and have the truthy values.', function () { // Test case that ensures all name(s) are defined and don't have the empty values.
            allFeeds.forEach(function (container) {
                expect(container.name).toBeDefined();
                expect(container.name).toBeTruthy();
            });
        });

    });


    describe("The menu", function () {

        icon = $('.menu-icon-link'); //Grabs the hambuger icon


        it("Menu Element is Hidden by default", function () { //To check if the menu is hidden by default or not.
            expect($('body').attr('class')).toMatch("menu-hidden");
        });

        it("Menu Hamburger Icon works correctly", function () {

            icon.click(); //Perform a click on the icon: unhide pane.
            icon.click(); //Perform a click on the icon: hide pane.
            expect($('body').attr('class')).toMatch("menu-hidden"); //Check if the clicks were performed correctly.

        });

    });


    describe("Initial Entries", function () { //To check if initial entries are present.
        beforeEach(function (done) {
            loadFeed(0, done);
        });

        it('are present', function () {
            expect($('.feed .entry').length).toBeGreaterThan(0);
        });
    });

    describe("New Feed Selection", function () { //To check loadFeed() actually changes content
        var withoutLoad;
        var withLoad;


        withoutLoad = $('.entry').length; //Before the api result is fetched.

        
        beforeEach(function () {
            loadFeed(1, function() {
                console.log($(".feed").children("h1"));
                loadFeed(2, function(){
                    console.log($(".feed").html());
                });
            });
        });

        it("changes content", function () {
            withLoad = $('.entry').length;
            expect(withoutLoad).toEqual(0); //Nothing was loaded before.
            expect(withLoad).toEqual(2); //Two feeds loaded, desired.
        });
    });

}());