## Feed Reader Testing

A project with [Jasmine](https://jasmine.github.io/2.1/introduction) testing syntax.

## OverView

The App uses the concepts of [Jasmine](https://jasmine.github.io/2.1/introduction) framework to test for the expectation from the application with respect to the actual output given by the application.

## Functionalities Tested


* The click events. 
* Asynchronous calls. 
* Definition and values of variables.
* Affect on DOM state after calls to DOM modifying functions. 


## Steps to open the Application

* Download the folder feedreader.zip
* Unzip the folder by using the *Extract Here* option in the right click dropdown
* Open the index.html file in your browser.


## Dependencies

* [Jasmine 2.1.2 Framework](https://jasmine.github.io/2.1/introduction) - The Js Code Testing Framework


## Tester

* **Anshuman Upadhyay** - *Profile* - [Github Pages](https://anshup7.github.io/profile)

## License

This project is free and open source.

## Acknowledgments

* Hat tip to the Application Developer who's code was used.
* Udacity Mentors.
